package pe.edu.upeu.microserviceenviroment.infrastructure.adapters.output.persistence.mapper;

import org.mapstruct.Mapper;
import pe.edu.upeu.microserviceenviroment.domain.model.AcademicSpace;
import pe.edu.upeu.microserviceenviroment.infrastructure.adapters.output.persistence.entity.AcademicSpaceEntity;

import java.util.List;

@Mapper(componentModel = "spring", uses = {
        TypeAcademicSpacePersistenceMapper.class, FloorPersistenceMapper.class, StatePersistenceMapper.class
})
public interface AcademicSpacePersistenceMapper {
    AcademicSpaceEntity toAcademicSpaceEntity(AcademicSpace academicSpace);
    AcademicSpace toAcademicSpace(AcademicSpaceEntity entity);
    List<AcademicSpace> toAcademicSpaceList(List<AcademicSpaceEntity> entityList);
}
