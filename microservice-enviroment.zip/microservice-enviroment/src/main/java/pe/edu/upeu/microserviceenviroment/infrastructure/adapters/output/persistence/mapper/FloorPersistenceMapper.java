package pe.edu.upeu.microserviceenviroment.infrastructure.adapters.output.persistence.mapper;

import org.mapstruct.Mapper;
import pe.edu.upeu.microserviceenviroment.domain.model.Floor;
import pe.edu.upeu.microserviceenviroment.infrastructure.adapters.output.persistence.entity.FloorEntity;

import java.util.List;

@Mapper(componentModel = "spring", uses = {BuildingPersistenceMapper.class})
public interface FloorPersistenceMapper {

    FloorEntity toFloorEntity(Floor floor);
    Floor toFloor(FloorEntity entity);
    List<Floor> toFloorList(List<FloorEntity> entityList);
}
