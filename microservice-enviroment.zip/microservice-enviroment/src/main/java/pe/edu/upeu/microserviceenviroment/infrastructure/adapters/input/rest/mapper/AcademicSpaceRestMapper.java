package pe.edu.upeu.microserviceenviroment.infrastructure.adapters.input.rest.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import pe.edu.upeu.microserviceenviroment.domain.model.AcademicSpace;
import pe.edu.upeu.microserviceenviroment.infrastructure.adapters.input.rest.model.request.AcademicSpaceCreateRequest;
import pe.edu.upeu.microserviceenviroment.infrastructure.adapters.input.rest.model.response.AcademicSpaceResponse;

import java.util.List;

@Mapper(componentModel = "spring", unmappedSourcePolicy = ReportingPolicy.IGNORE, uses = {
        TypeAcademicSpaceRestMapper.class, FloorRestMapper.class, StateRestMapper.class
})
public interface AcademicSpaceRestMapper {
    AcademicSpace toAcademicSpace(AcademicSpaceCreateRequest request);
    AcademicSpaceResponse toAcademicSpaceResponse(AcademicSpace academicSpace);
    List<AcademicSpaceResponse> toAcademicSpaceResponseList(List<AcademicSpace> academicSpaces);
}
