package pe.edu.upeu.microserviceenviroment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceEnviromentApplication {

    public static void main(String[] args) {
        SpringApplication.run(MicroserviceEnviromentApplication.class, args);
    }

}
