package pe.edu.upeu.microserviceenviroment.infrastructure.adapters.input.rest.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import pe.edu.upeu.microserviceenviroment.domain.model.Floor;
import pe.edu.upeu.microserviceenviroment.infrastructure.adapters.input.rest.model.request.FloorCreateRequest;
import pe.edu.upeu.microserviceenviroment.infrastructure.adapters.input.rest.model.response.FloorResponse;

import java.util.List;

@Mapper(componentModel = "spring", unmappedSourcePolicy = ReportingPolicy.IGNORE, uses = {BuildingRestMapper.class})
public interface FloorRestMapper {

    Floor toFloor(FloorCreateRequest request);
    FloorResponse toFloorResponse(Floor floor);
    List<FloorResponse> toFloorResponseList(List<Floor> floors);
}
