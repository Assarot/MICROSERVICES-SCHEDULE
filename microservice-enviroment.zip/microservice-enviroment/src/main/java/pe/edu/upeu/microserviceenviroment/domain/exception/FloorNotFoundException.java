package pe.edu.upeu.microserviceenviroment.domain.exception;

public class FloorNotFoundException extends RuntimeException {
}
