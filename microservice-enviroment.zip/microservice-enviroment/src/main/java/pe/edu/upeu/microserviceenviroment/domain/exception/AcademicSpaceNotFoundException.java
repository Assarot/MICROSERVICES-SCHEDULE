package pe.edu.upeu.microserviceenviroment.domain.exception;

public class AcademicSpaceNotFoundException extends RuntimeException {
}
