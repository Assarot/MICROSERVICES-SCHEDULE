package pe.edu.upeu.microserviceenviroment.domain.exception;

public class BuildingNotFoundException extends RuntimeException {
}
